# A1_HiringTrends

Clone this into "C:" Drive in a Folder Named "ADS"
